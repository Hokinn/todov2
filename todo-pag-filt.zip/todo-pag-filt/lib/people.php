<?php

    function load_people(){
        $data = file_get_contents("database/people.json");
        $people = json_decode($data, true);
        return $people;
    }

?>