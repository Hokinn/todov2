
<?php
    include 'lib/task.php';
    include 'lib/people.php';
    $tasks = load_tasks(); // se foloseste return in structura data
    $people = load_people();
?>

<?php 
    // prezentam, vivod
    include 'templates/task-list.php';
    include 'templates/task-form.php';
?>