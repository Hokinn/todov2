    <select name="employer">
        <option>Select employer</option>
        <?php foreach($people as $person) { ?>
            <option>
                <?php echo $person['name']; ?>
                (<?php echo $person['job']; ?>)
            </option> 
        <?php } ?>
    </select>